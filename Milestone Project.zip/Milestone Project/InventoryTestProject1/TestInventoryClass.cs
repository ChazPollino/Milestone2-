using Milestone_Project;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Linq;


namespace InventoryTestProject1
{
    [TestClass]
    public class TestInventoryClass
    {


        [TestMethod]
        public void DisplayButton_Click()
        {
            string[] lines = File.ReadAllLines("D:\\Programming\\Milestone Project\\Milestone Project\\bin\\DisplayInventory.txt");

            string[] values;

            for (int i = 0; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split('/');
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }

            }
        }
    }
}